﻿using Surgery;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        MedicalClinic medicalClinic = new MedicalClinic();
        MedicalClinicDbContext dbContext = new MedicalClinicDbContext();
        public MainWindow()
        {
            InitializeComponent();
            //using (dbContext  )
            //{
                
            //    var patients = dbContext.Patients.ToList();

            //    var patientsWithOperations = dbContext.Patients.Include(p => p.Operations).ToList();
            //    lstPatients.ItemsSource = new ObservableCollection<Patient>(patients);
            //}
            LoadPatientsWithOperations();
            //medicalClinic = (MedicalClinic)MedicalClinic.ReadXML("filename.xml"); // nazwa pliku + właściwa ścieżka!
            //if (medicalClinic is object)
            //{
            Director director1 = new Director("John", "Smith", 12345875, EnumDegree.MSc);
            
            medicalClinic.Name = "THE ROYAL CRACOW HOSPITAL";
                txtName.Text = medicalClinic.Name;
                txtDirector.Text = director1.ToString();
            
            //}
        }
        private void LoadPatientsWithOperations()
        {
            using (var dbContext = new MedicalClinicDbContext())
            {
                var patients = dbContext.Patients.ToList();
                foreach (var patient in patients)
                {
                    dbContext.Entry(patient)
                             .Collection(p => p.Operations)
                             .Load();
                }

                lstPatients.ItemsSource = new ObservableCollection<Patient>(patients);
            }
        }


        private void buttonAdd_Click(object sender, RoutedEventArgs e)
        {
            Patient p = new Patient();
            PersonWindow window = new PersonWindow(p);
            bool? result = window.ShowDialog();
            if (result == true)
            {
                if (medicalClinic.Patients.Any(existingPatient => existingPatient.Pesel == p.Pesel))
                {
                    MessageBox.Show("The patient with the provided PESEL number already exists.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                medicalClinic.AddPatient(p);
                lstPatients.ItemsSource = medicalClinic.Patients;
                lstOperation.ItemsSource = null;
                lstOperation.ItemsSource = p.Operations;
                txtpay.Text = p.CalculateCost().ToString("C2");

                p.SaveToDatabase();

                lstPatients_SelectionChanged(lstPatients, null);
                txtpay.Text = p.CalculateCost().ToString("C2");
            }
        }

        private void buttonRemove_Click(object sender, RoutedEventArgs e)
        {
            if (lstPatients.SelectedIndex > -1)
            {
                using (var dbContext = new MedicalClinicDbContext())
                {
                    foreach (var item in lstPatients.SelectedItems)
                    {
                        medicalClinic.RemovePatient(((Patient)item));
                    }

                    lstPatients.ItemsSource = new ObservableCollection<Patient>(dbContext.Patients.ToList());
                }
            }
        }

        private void buttonSort_Click(object sender, RoutedEventArgs e)
        {
            SortWindow sortWindow = new SortWindow();
            if (sortWindow.ShowDialog() == true)
            {
                string wybranaOpcja = sortWindow.WybranaOpcjaSortowania;
                using (var dbContext = new MedicalClinicDbContext())
                {
                    IQueryable<Patient> sortedPatientsQuery = null;
                    if (wybranaOpcja == "Surname")
                    {
                        sortedPatientsQuery = dbContext.Patients.OrderBy(p => p.Surname);
                    }
                    else if (wybranaOpcja == "Age")
                    {
                        sortedPatientsQuery = dbContext.Patients.OrderBy(p => p.DateOfBirth);
                    }
                    else if (wybranaOpcja == "PESEL")
                    {
                        sortedPatientsQuery = dbContext.Patients.OrderBy(p => p.Pesel);
                    }

                    if (sortedPatientsQuery != null)
                    {
                        var sortedPatients = sortedPatientsQuery.ToList();
                        foreach (var patient in sortedPatients)
                        {
                            dbContext.Entry(patient).Collection(p => p.Operations).Load();
                        }
                        lstPatients.ItemsSource = new ObservableCollection<Patient>(sortedPatients);
                    }
                }
            }
        }
        private void buttonEdit_Click(object sender, RoutedEventArgs e)
        {
            
        }
        private ObservableCollection<Operation> currentPatientOperations;
        private void buttonEdit_Click_1(object sender, RoutedEventArgs e)
        {
            if (lstPatients.SelectedItem != null && lstPatients.SelectedItem is Patient selectedPatient)
            {
                using (var db = new MedicalClinicDbContext())
                {
                    Patient patientFromDb = db.Patients.FirstOrDefault(p => p.Pesel == selectedPatient.Pesel);

                    if (patientFromDb != null)
                    {
                        db.Entry(patientFromDb).Collection(p => p.Operations).Load();

                        // Przechowaj operacje pacjenta w osobnej kolekcji
                        currentPatientOperations = new ObservableCollection<Operation>(patientFromDb.Operations);

                        PersonWindow personWindow = new PersonWindow(patientFromDb);
                        bool? result = personWindow.ShowDialog();

                        if (result.HasValue && result.Value)
                        {
                            db.Entry(patientFromDb).CurrentValues.SetValues(selectedPatient);

                            foreach (var operation in selectedPatient.Operations)
                            {
                                if (!patientFromDb.Operations.Any(o => o.OperationId == operation.OperationId))
                                {
                                    db.Operations.Attach(operation);
                                    patientFromDb.Operations.Add(operation);
                                }
                            }

                            // Zapisz zmiany w bazie danych
                            db.SaveChanges();

                            // Zaktualizuj listę operacji pacjenta w interfejsie użytkownika
                            lstOperation.ItemsSource = patientFromDb.Operations.ToList();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Patient not found in the database.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a patient for editing.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }




        private void buttonSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = txtSearch.Text.Trim().ToUpper();
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                MessageBox.Show("Please enter a phrase to search for.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            using (var db = new MedicalClinicDbContext())
            {
                
                var searchResults = db.Patients
                    .Where(patient =>
                        patient.Name.ToUpper().Contains(searchTerm) ||
                        patient.Surname.ToUpper().Contains(searchTerm) ||
                        patient.Pesel.ToUpper().Contains(searchTerm)
                    )
                    .ToList(); 

                if (searchResults.Count > 0)
                {
                    lstPatients.ItemsSource = new ObservableCollection<Patient>(searchResults);
                }
                else
                {
                    MessageBox.Show("No patients found matching the search criteria.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                    lstPatients.ItemsSource = null;
                }
            }
        }
        private void buttonClear_Click(object sender, RoutedEventArgs e)
        {
            txtSearch.Text = ""; 
            using (var db = new MedicalClinicDbContext())
            {
                lstPatients.ItemsSource = new ObservableCollection<Patient>(db.Patients.ToList());
            }
        }
        public void lstPatients_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Patient chosen = (Patient)lstPatients.SelectedItem;
            if (chosen != null)
            {
                lstOperation.ItemsSource = new ObservableCollection<Operation>(chosen.Operations);
                txtpay.Text = chosen.CalculateCost().ToString("C2");
            }
        }
    }
    }
    
    

