﻿using Surgery;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy PersonWindow.xaml
    /// </summary>
    public partial class PersonWindow : Window
    {
        Patient patient = new Patient();

        public PersonWindow(Patient p)
        {
            InitializeComponent();
            patient = p;

            txtName.Text = patient.Name;
            txtSurname.Text = patient.Surname;
            txtPESEL.Text = patient.Pesel;
            txtCity.Text = patient.City;
            txtStreet.Text = patient.Street;
            if (comboGender.Text == "Female")
            {
                patient.Gender = EnumGender.Female;
            }
            else
            {
                patient.Gender = EnumGender.Male;
            }

            //if (comboAppointment.SelectedItem != null)
            //{
            //    string selectedAppointment = (comboAppointment.SelectedItem as ComboBoxItem).Content.ToString();

            //    DateTime selectedDate = datePicker.SelectedDate.HasValue ? datePicker.SelectedDate.Value : DateTime.Now;

            //    if (selectedAppointment == "Surgeon")
            //    {
            //        Operation surgeryOperation = new Operation(selectedDate, 1, EnumOperation.Surgeon);

            //        patient.Operations.Add(surgeryOperation);
            //    }
            //    if (selectedAppointment == "FamilyDoctor")
            //    {
            //        Operation surgeryOperation = new Operation(selectedDate, 1, EnumOperation.FamilyDoctor);

            //        patient.Operations.Add(surgeryOperation);
            //    }
            //    if (selectedAppointment == "Dentist")
            //    {
            //        Operation surgeryOperation = new Operation(selectedDate, 1, EnumOperation.Dentist);

            //        patient.Operations.Add(surgeryOperation);
            //    }
            //    if (selectedAppointment == "Physiotherapist")
            //    {
            //        Operation surgeryOperation = new Operation(selectedDate, 2, EnumOperation.Physiotherapist);

            //        patient.Operations.Add(surgeryOperation);
            //    }

            //}
            


        }
        private void datePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            
            if (datePicker.SelectedDate.HasValue)
            {
                DateTime dateOfBirth1 = new DateTime(datePicker.SelectedDate.Value.Year, datePicker.SelectedDate.Value.Month, datePicker.SelectedDate.Value.Day);

                int age = patient.CountAge1(dateOfBirth1); 
                txtAge.Text = age.ToString();
            }
        }


        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            if (txtPESEL.Text != "" && txtName.Text != "" && txtSurname.Text != "")
            {
                if (txtPESEL.Text.Length != 9)
                {
                    MessageBox.Show("The PESEL number must have 9 digits.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (ContainsDigits(txtName.Text) || ContainsDigits(txtSurname.Text))
                {
                    MessageBox.Show("The fields for first name and last name cannot contain digits.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                if (!datePicker.SelectedDate.HasValue)
                {
                    MessageBox.Show("Please select a date of birth.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                patient.Pesel = txtPESEL.Text;
                patient.Name = txtName.Text.ToUpper();
                patient.Surname = txtSurname.Text.ToUpper();
                patient.Street = txtStreet.Text;
                patient.City = txtCity.Text;
                patient.ZipCode = txtZipCode.Text;
                patient.DateOfBirth = datePicker.SelectedDate.Value;

                if (comboAppointment.SelectedItem != null && datePickerAppointment.SelectedDate.HasValue)
                {
                    string selectedAppointment = (comboAppointment.SelectedItem as ComboBoxItem).Content.ToString();
                    DateTime selectedDate = datePickerAppointment.SelectedDate.Value;
                    EnumOperation selectedOperation;

                    switch (selectedAppointment)
                    {
                        case "Surgeon":
                            selectedOperation = EnumOperation.Surgeon;
                            break;
                        case "FamilyDoctor":
                            selectedOperation = EnumOperation.FamilyDoctor;
                            break;
                        case "Dentist":
                            selectedOperation = EnumOperation.Dentist;
                            break;
                        case "Physiotherapist":
                            selectedOperation = EnumOperation.Physiotherapist;
                            break;
                        default:
                            selectedOperation = EnumOperation.Surgeon;
                            break;
                    }

                    Operation operation = new Operation(selectedDate, 1, selectedOperation);
                    patient.Operations.Add(operation); 
                }
                else
                {
                    MessageBox.Show("Please select an appointment type and date.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Zapisz pacjenta do bazy danych
                DataContext = this;

                patient.SaveToDatabase();

                DialogResult = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool ContainsDigits(string text)
        {
            foreach (char c in text)
            {
                if (char.IsDigit(c))
                {
                    return true;
                }
            }
            return false;
        }
        private void txtZipCode_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (textBox.Text == "00-000")
            {
                textBox.Text = "";
            }
        }

        private void txtZipCode_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "00-000";
            }
        }
        private void txtZipCode_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
           
            if (!Regex.IsMatch(e.Text, @"[0-9\-]") || ((TextBox)sender).Text.Length >= 6)
            {
                e.Handled = true; 
            }
        }

        private void buttonCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
   
}
