﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy SortWindow.xaml
    /// </summary>
    public partial class SortWindow : Window
    {
        public string WybranaOpcjaSortowania { get; private set; }

        public SortWindow()
        {
            InitializeComponent();
            WybranaOpcjaSortowania = string.Empty;
        }

        private void buttonOK_Click(object sender, RoutedEventArgs e)
        {
            if (radioButtonSurname.IsChecked == true)
            {
                WybranaOpcjaSortowania = "Surname";
            }
            else if (radioButtonAge.IsChecked == true)
            {
                WybranaOpcjaSortowania = "Age";
            }
            else if (radioButtonPESEL.IsChecked == true)
            {
                WybranaOpcjaSortowania = "PESEL";
            }

            DialogResult = true;
        }
        private void buttonCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            this.Close();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}

    

