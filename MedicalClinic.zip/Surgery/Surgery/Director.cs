﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Surgery
{
    public class Director : Person
    {
        long phoneNumber;
        EnumDegree degree;

        public Director(string name, string surname, long phoneNumber, EnumDegree degree) : base(name, surname)
        {
            this.PhoneNumber = phoneNumber;
            this.Degree = degree;
            
        }

        public long PhoneNumber { get => phoneNumber; set => phoneNumber = value; }
        public EnumDegree Degree { get => degree; set => degree = value; }

        public override string ToString()
        {
            return $"{Degree}" + " " +base.ToString() +" " + $"Phone number: {PhoneNumber.ToString("000-000-000")}";
        }
    }
    
    public enum EnumDegree {MSc, PhD, prof, prof_dr_hab}

}
