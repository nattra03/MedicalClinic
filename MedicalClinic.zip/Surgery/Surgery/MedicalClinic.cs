﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Surgery
{
    public class MedicalClinic
    {
        string name;
        Director director;
        private List<Patient> patients;

        public string Name { get => name; set => name = value; }

        public List<Patient> Patients { get => patients; set => patients = value; }
        public Director Director { get => director; set => director = value; }

        public MedicalClinic() 
        {
            
            Patients = new List<Patient>();
        }
        public MedicalClinic(string name) : this()
        {
            Name = name;

        }
        public MedicalClinic(string nazwa, Director director) : this() 
        {
            Director = director;
        }
        public void AddPatient(Patient p)
        {
            if(p is not null)
            {
                Patients.Add(p);
            }
        }
        public void RemovePatient(Patient p)
        {
            if (p is not null)
            {
                using (var dbContext = new MedicalClinicDbContext())
                {
                    
                    var operationsToRemove = dbContext.Operations.Where(operation => operation.Patient.Pesel == p.Pesel).ToList();
                    foreach (var operation in operationsToRemove)
                    {
                        dbContext.Operations.Remove(operation);
                    }

                    
                    var patientToRemove = dbContext.Patients.FirstOrDefault(patient => patient.Pesel == p.Pesel);
                    if (patientToRemove != null)
                    {
                        dbContext.Patients.Remove(patientToRemove);
                        dbContext.SaveChanges();
                    }
                }
            }
        }

        public void SortSurnameName()
        {
            Patients.Sort();
        }
        public void SortAge1(DateTime comparisonDate)
        {
            Patients.Sort((p1, p2) => p1.CountAge1(comparisonDate).CompareTo(p2.CountAge1(comparisonDate)));
        }
        public void SortAge()
        {
            Patients.Sort((p1, p2) => p1.CountAge().CompareTo(p2.CountAge()));

        }
        public void SortPESEL()
        {
            Comparison<Patient> cmp =
                (Patient p1, Patient p2) =>
                p1.Pesel.CompareTo(p2.Pesel);
            Patients.Sort(cmp);
        }
        public bool IsPatient(Patient p)
        {
            Patient? patient = Patients
                .FirstOrDefault(c => c.Equals(p));
            return patient != null;
        }
        public override string ToString()
        {
            StringBuilder sb = new();
            sb.AppendLine($"Medical clinic: {Name}");
            if (Director is not null)
            {
                sb.AppendLine($"Director: {Director}");
            }
            if (Patients.Any())
            {
                sb.AppendLine("Patients:");
                foreach (Patient p in Patients)
                {
                    sb.AppendLine(p.ToString());
                }
            }
            return sb.ToString();
        }
        public void SaveXML(string namefile)
        {
            using StreamWriter sw = new(namefile);
            XmlSerializer xs = new(typeof(MedicalClinic));
            xs.Serialize(sw, this);
        }
        public static MedicalClinic? ReadXML(string namefile)
        {
            if (!File.Exists(namefile))
            {
                return null;
            }
            using StreamReader sw = new(namefile);
            XmlSerializer xs = new(typeof(MedicalClinic));
            return xs.Deserialize(sw) as MedicalClinic;
        }

    }
}
