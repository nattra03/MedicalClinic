﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Reflection.Emit;
using System.ComponentModel.DataAnnotations;



namespace Surgery
{
    public class MedicalClinicDbContext : DbContext
    {
        public DbSet<Patient> Patients { get; set; }
        public DbSet<Operation> Operations { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Operation>()
                .HasRequired<Patient>(o => o.Patient)  
                .WithMany(p => p.Operations)          
                .HasForeignKey(o => o.PatientPesel);  
        }

    }
}
