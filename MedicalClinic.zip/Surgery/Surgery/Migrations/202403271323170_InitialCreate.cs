﻿namespace Surgery.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Patients",
                c => new
                    {
                        Pesel = c.String(nullable: false, maxLength: 128),
                        City = c.String(),
                        Street = c.String(),
                        ZipCode = c.String(),
                        Gender = c.Int(nullable: false),
                        DateOfBirth = c.DateTime(nullable: false),
                        Active = c.Boolean(nullable: false),
                        Name = c.String(),
                        Surname = c.String(),
                    })
                .PrimaryKey(t => t.Pesel);
            
            CreateTable(
                "dbo.Operations",
                c => new
                    {
                        OperationId = c.Int(nullable: false, identity: true),
                        DateOperation = c.DateTime(nullable: false),
                        Time = c.Decimal(nullable: false, precision: 18, scale: 2),
                        OperationType = c.Int(nullable: false),
                        Patient_Pesel = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.OperationId)
                .ForeignKey("dbo.Patients", t => t.Patient_Pesel)
                .Index(t => t.Patient_Pesel);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Operations", "Patient_Pesel", "dbo.Patients");
            DropIndex("dbo.Operations", new[] { "Patient_Pesel" });
            DropTable("dbo.Operations");
            DropTable("dbo.Patients");
        }
    }
}
