﻿namespace Surgery.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NazwaMigracji : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Patients", "Active");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Patients", "Active", c => c.Boolean(nullable: false));
        }
    }
}
