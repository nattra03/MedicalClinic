﻿namespace Surgery.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NazawaMigracjiii : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Operations", "PatientId", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Operations", "PatientId");
        }
    }
}
