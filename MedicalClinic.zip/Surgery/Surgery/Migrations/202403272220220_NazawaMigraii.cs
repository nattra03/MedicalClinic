﻿namespace Surgery.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NazawaMigraii : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Operations", "PatientPesel", c => c.Int(nullable: false));
            DropColumn("dbo.Operations", "PatientId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Operations", "PatientId", c => c.Int(nullable: false));
            DropColumn("dbo.Operations", "PatientPesel");
        }
    }
}
