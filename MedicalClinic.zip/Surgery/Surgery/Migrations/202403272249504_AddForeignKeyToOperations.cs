﻿namespace Surgery.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddForeignKeyToOperations : DbMigration
    {
        public override void Up()
        {
            Sql("ALTER TABLE dbo.Operations ADD CONSTRAINT FK_Operations_Patients_Pesel FOREIGN KEY (Patient_Pesel) REFERENCES dbo.Patients (Pesel)");

        }

        public override void Down()
        {
            Sql("ALTER TABLE dbo.Operations DROP CONSTRAINT FK_Operations_Patients_Pesel");
        }
    }
}
