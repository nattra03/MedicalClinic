﻿namespace Surgery.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NazwaTwojejMigracji : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Operations", "Patient_Pesel", "dbo.Patients");
            DropIndex("dbo.Operations", new[] { "Patient_Pesel" });
            DropColumn("dbo.Operations", "PatientPesel");
            RenameColumn(table: "dbo.Operations", name: "Patient_Pesel", newName: "PatientPesel");
            AlterColumn("dbo.Operations", "PatientPesel", c => c.String(nullable: false, maxLength: 128));
            AlterColumn("dbo.Operations", "PatientPesel", c => c.String(nullable: false, maxLength: 128));
            CreateIndex("dbo.Operations", "PatientPesel");
            AddForeignKey("dbo.Operations", "PatientPesel", "dbo.Patients", "Pesel", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Operations", "PatientPesel", "dbo.Patients");
            DropIndex("dbo.Operations", new[] { "PatientPesel" });
            AlterColumn("dbo.Operations", "PatientPesel", c => c.String(maxLength: 128));
            AlterColumn("dbo.Operations", "PatientPesel", c => c.Int(nullable: false));
            RenameColumn(table: "dbo.Operations", name: "PatientPesel", newName: "Patient_Pesel");
            AddColumn("dbo.Operations", "PatientPesel", c => c.Int(nullable: false));
            CreateIndex("dbo.Operations", "Patient_Pesel");
            AddForeignKey("dbo.Operations", "Patient_Pesel", "dbo.Patients", "Pesel");
        }
    }
}
