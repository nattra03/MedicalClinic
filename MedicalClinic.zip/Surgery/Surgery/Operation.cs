﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Surgery
{
    public class Operation
    {
         
        public int OperationId { get; set; }

        
        public string PatientPesel { get; set; }

        public DateTime DateOperation { get; set; }
        public decimal Time { get; set; }
        public EnumOperation OperationType { get; set; }
        public Patient Patient { get; set; }

        
        public Operation()
        {
        }

        public Operation(DateTime dateOperation, decimal time, EnumOperation operationType)
        {
            DateOperation = dateOperation;
            Time = time;
            OperationType = operationType;
        }

        public override string ToString()
        {
            return $"Date: {DateOperation.ToString("yyyy-MMM-dd")}, medical: {OperationType}, cost: {Cost().ToString("C2")}";
        }

        public decimal Cost()
        {
            return Time * (decimal)OperationType;
        }
    }

    public enum EnumOperation
    {
        Surgeon = 90,
        FamilyDoctor = 50,
        Dentist = 60,
        Physiotherapist = 60,

    }
}
