﻿using System;
using System.Buffers;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

using System.ComponentModel.DataAnnotations.Schema;

namespace Surgery
{
    public class Patient : Person, IEquatable<Patient>, IComparable<Patient>
    {
        string city;
        string street;
        string zipCode;
        string pesel;
        EnumGender gender;
        DateTime dateOfBirth;
        public ICollection<Operation> Operations { get; } = new List<Operation>();
        //List<Operation> operations = new List<Operation>();


        public string City { get => city; set => city = value; }
        public string Street { get => street; set => street = value; }
        public string ZipCode { get => zipCode; set => zipCode = value; }

        [Key]
        public string Pesel { get => pesel; set => pesel = value; }

        public EnumGender Gender { get => gender; set => gender = value; }
        public DateTime DateOfBirth { get => dateOfBirth; set => dateOfBirth = value; }
        
        //public List<Operation> Operations { get => operations; set => operations = value; }
        //public ICollection<Operation> Operations { get => operations; set => operations = value; }

        public Patient(): base() 
        {
            
        }

        public Patient(string name, string surname, string pesel, string city, string street, string zipCode, DateTime dateOfBirth) : base(name, surname)         
        {
            
            this.pesel = pesel;
            City = city;
            Street = street;
            ZipCode = zipCode;
            DateOfBirth = dateOfBirth;
        }

        #region DataBase

        public void SaveToDatabase()
{
    using (var db = new MedicalClinicDbContext())
    {
        Patient existingPatient = db.Patients.FirstOrDefault(g => g.Pesel == Pesel);

        if (existingPatient != null)
        {
            
            db.Entry(existingPatient).Collection(p => p.Operations).Load();

            
            //foreach (var operation in Operations)
            //{
            //    existingPatient.Operations.Add(operation);
            //}
        }
        else
        {
            db.Patients.Add(this);
        }

        db.SaveChanges();
    }
}

        #endregion Database

        public int CountAge()
        {
            return (int)(DateTime.Now - dateOfBirth).TotalDays / 365;
        }
        public int CountAge1(DateTime dateOfBirth)
        {
            DateTime currentDate = DateTime.Today;
            int age = currentDate.Year - dateOfBirth.Year;
            if (dateOfBirth > currentDate.AddYears(-age))
            {
                age--;
            }
            return age;
        }
        //public EnumGender GenderType(string pesel)
        //{
        //    if (int.Parse(pesel[pesel.Length - 1].ToString()) % 2 == 0)
        //    {
        //        return EnumGender.Female;
        //    }
        //    return EnumGender.Male;
        //}
        public void AddOperation(Operation o)
        {
           this.Operations.Add(o);
        }
        public decimal CalculateCost()
        {
            decimal sum = 0;
            foreach (Operation o in Operations)
            {
                sum += o.Time * (decimal)o.OperationType;
            }
            return sum;
        }

        public override string ToString()
        {
            return base.ToString() + $"({Gender.ToString()}), ur. {this.dateOfBirth.ToString("yyyy-MM-dd")}, (PESEL: {Pesel}), {City}, {Street}, {ZipCode} ";
        }

        public bool Equals(Patient? other)
        {
            if (other == null) { return false; }
            return Pesel.Equals(other.Pesel);
        }

        public int CompareTo(Patient? other)
        {
            if (other == null) { return -1; }
            int cmp = Surname.CompareTo(other.Surname);
            if (cmp != 0) { return cmp; }
            return Name.CompareTo(other.Name);
        }
    }
    public enum EnumGender
    {
        Male, Female
    }
}
