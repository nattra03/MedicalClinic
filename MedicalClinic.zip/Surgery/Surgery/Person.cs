﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace Surgery
{
    public class Person
    {
        string name;
        string surname;
       

        

        public string Name { get => name; set => name = value; }
        public string Surname { get => surname; set => surname = value; }


        public Person() 
        {
            this.name = string.Empty;
            this.surname = string.Empty;
            
        }
        public Person(string name, string surname) : this()
        {
            this.name = name;
            this.surname = surname;
        }

        
        public override string ToString()
        {
            return $"{Name.ToUpper()} {Surname.ToUpper()},";
        }
    }
}
