﻿namespace Surgery
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Patient patient1 = new Patient("Natalia", "Kowalska", "123456789", "Krakow", "Warszawska", "123-098", new DateTime(2002, 09, 29));
            Console.WriteLine(patient1.ToString());
            Director director = new Director("Jan", "Kowalski", 123456789, EnumDegree.MSc);
            Console.WriteLine(director.ToString());
            MedicalClinic nowa = new MedicalClinic("MAWE", director);
            nowa.AddPatient(patient1 );
            Console.WriteLine(nowa.ToString());
        }
    }
}